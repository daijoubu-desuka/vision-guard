"""
build_report.py - Builds docs/VisionGuard_Documentation.pdf (2-4 pages) with reportlab.

HOW TO FINALISE YOUR REPORT
  1. Edit AUTHORS / SECTION below.
  2. Replace the images in docs/screenshots/ with screenshots from your own
     LIVE WEBCAM run (press P in the app) - keep the same file names.
  3. Update the TRIALS table with your own observations.
  4. python docs/build_report.py
"""
import os

from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer,
                                Table, TableStyle)

# ----------------------------------------------------------------- edit me
AUTHORS = "Adlawon, Anthony N. &nbsp;|&nbsp; Bantillo, Daniel M. &nbsp;|&nbsp; Abejay, Franz Jedd M."
SECTION = "Caraga State University - College of Computing and Information Sciences"
# -------------------------------------------------------------------------

HERE = os.path.dirname(os.path.abspath(__file__))
SHOT = os.path.join(HERE, "screenshots")
OUT = os.path.join(HERE, "VisionGuard_Documentation.pdf")

ss = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=ss["Normal"], fontName="Helvetica", fontSize=9.2, leading=12.2,
                      alignment=TA_JUSTIFY, spaceAfter=3)
SMALL = ParagraphStyle("small", parent=BODY, fontSize=8.2, leading=10.2, alignment=0)
CELL = ParagraphStyle("cell", parent=BODY, fontSize=8, leading=9.8, alignment=0, spaceAfter=0)
CAP = ParagraphStyle("cap", parent=BODY, fontSize=7.8, leading=9.6, alignment=0,
                     textColor=colors.HexColor("#333333"), spaceAfter=6)
H1 = ParagraphStyle("h1", parent=ss["Heading1"], fontName="Helvetica-Bold", fontSize=15, leading=18,
                    spaceAfter=2, textColor=colors.HexColor("#7a1f1f"))
H2 = ParagraphStyle("h2", parent=ss["Heading2"], fontName="Helvetica-Bold", fontSize=11, leading=13,
                    spaceBefore=7, spaceAfter=3, textColor=colors.HexColor("#7a1f1f"))
SUB = ParagraphStyle("sub", parent=BODY, alignment=0, fontSize=8.5, textColor=colors.HexColor("#555555"))


def P(text, style=BODY):
    return Paragraph(text, style)


def bullets(items):
    return [Paragraph(f"&bull;&nbsp; {t}", ParagraphStyle("b", parent=BODY, leftIndent=12, firstLineIndent=-9,
                                                           spaceAfter=1.5)) for t in items]


def figure(name, caption, width=8.6 * cm):
    img = Image(os.path.join(SHOT, name))
    ratio = img.imageHeight / float(img.imageWidth)
    img.drawWidth, img.drawHeight = width, width * ratio
    return [img, P(caption, CAP)]


def table(rows, widths, header=True):
    data = [[P(str(c), CELL) for c in r] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1)
    style = [("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#999999")),
             ("VALIGN", (0, 0), (-1, -1), "TOP"),
             ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]
    if header:
        style.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eadada")))
    t.setStyle(TableStyle(style))
    return t


story = []

# ------------------------------------------------------------------ page 1
story += [P("CSC 126 Computer Vision - Midterm Project Documentation", SUB),
          P("VisionGuard: Real-Time Drowsiness and Mood Detection with a Motion-Based People Counter "
            "using Classical OpenCV Techniques", H1),
          P(f"{AUTHORS}<br/>{SECTION}", SUB)]

story += [P("1. Title and Objectives", H2)]
story += bullets([
    "<b>Drowsiness monitor:</b> detect a tired driver / student / night-shift operator from a webcam in real time "
    "(prolonged eye closure, yawning, high PERCLOS) and raise an audible and visual alarm.",
    "<b>Mood detector:</b> estimate the user's mood (happy, neutral, sad, surprised, angry, tired) from the face and "
    "show a live mood timeline and session summary.",
    "<b>People counter:</b> detect people in the camera view (motion driven, with Haar face detection), count in real "
    "time how many people are in view, keep counting people who stand still, and <b>beep</b>, save a snapshot and log "
    "an event when <b>more than one</b> person is present. Entries and exits across a line are counted too.",
    "<b>Object tracker:</b> follow any object selected by the user using its colour.",
    "Apply <b>all six</b> laboratory topics (a-f) using only classical OpenCV (no deep learning), running on a "
    "live webcam feed, a recorded video or a static image.",
    "Provide a usable desktop-style interface: resizable / maximizable window, toolbar buttons, a small "
    "always-on-top <b>mini view</b>, fullscreen, and an immediate, clean exit when the window is closed.",
])

story += [P("2. Real-World Problem / Use Case", H2),
          P("Fatigue slows reaction time and is a recognised contributing factor in road accidents and workplace "
            "errors, yet most people cannot reliably judge their own drowsiness. A camera-based monitor can watch "
            "the eyes and mouth continuously and warn before attention is lost. The same camera can supervise a place "
            "where only one person should be present at a time (a single-person exam or study booth, a control or server "
            "room, a kiosk): instead of recording hours of footage, the system reacts to motion, tells people from other "
            "moving things, shows how many people are in view in real time and sounds an alarm with saved evidence when "
            "a second person appears. VisionGuard combines both "
            "needs in one low-cost application that needs only a laptop webcam. The mood detector adds a wellbeing "
            "dimension: a tired or stressed face can be flagged early, and the session summary shows how the user felt "
            "over time (useful for study sessions, driver-fatigue studies or simple human-computer interaction demos).")]

story += [P("3. Techniques Used (OpenCV)", H2)]
rows = [["Topic", "How it is used in VisionGuard", "Main OpenCV functions"],
        ["a. Image Operations",
         "Resize to 640 px, mirror flip, BGR to gray, automatic <b>gamma correction</b> (LUT) for dark rooms, "
         "<b>CLAHE</b> contrast enhancement before detection, Gaussian blur before background subtraction, "
         "masking and overlays for visualisation.",
         "resize, flip, cvtColor, LUT, createCLAHE, GaussianBlur, bitwise_and, addWeighted"],
        ["b. Image Segmentation",
         "<b>MOG2</b> background subtraction separates moving foreground; threshold removes shadows; "
         "morphological open/close/dilate clean the mask. In tracker mode, an <b>HSV hue histogram</b> "
         "back-projection segments the chosen colour.",
         "createBackgroundSubtractorMOG2, threshold, medianBlur, morphologyEx, dilate, inRange, calcBackProject"],
        ["c. Haar Cascade Classifier",
         "Face detection (largest face), eye detection in the upper face region, <b>smile detection</b> in the lower "
         "face (supports the mood rules), and a <b>full-frame face search</b> for the people counter: a face inside a "
         "moving blob makes it a PERSON (two faces = two people), a face outside every blob is a person who stands still.",
         "CascadeClassifier.detectMultiScale (frontalface_alt2, eye, smile)"],
        ["d. Image Analysis and Transformation",
         "Contours with area filtering, bounding boxes and <b>image moments</b> (centroids); convex hulls of eyes "
         "and mouth; grayscale histogram; the face is <b>rotated by an affine transform</b> so the eyes are "
         "horizontal.",
         "findContours, contourArea, moments, boundingRect, convexHull, calcHist, getRotationMatrix2D, warpAffine"],
        ["e. Motion and Object Tracking",
         "Centroid tracker gives each moving object a persistent ID, trail and direction arrow; the <b>people counter</b> "
         "turns tracked blobs and faces into the live head-count; a virtual line counts IN / OUT; <b>CamShift</b> follows "
         "the user-selected coloured object.",
         "MOG2, centroid matching, polylines, arrowedLine, CamShift"],
        ["f. Facial Landmark Detection",
         "68 landmarks (LBF model) give the <b>Eye Aspect Ratio</b> (eye closure), <b>Mouth Aspect Ratio</b> "
         "(yawn), head roll, and the face measurements used for <b>mood</b> (mouth-corner lift, mouth width, "
         "eyebrow height, eyebrow gap).",
         "cv2.face.createFacemarkLBF, fit"]]
story += [table(rows, [3.0 * cm, 9.2 * cm, 5.3 * cm])]
story += [Spacer(1, 4),
          P("<b>Drowsiness logic.</b> EAR = (||p2-p6|| + ||p3-p5||) / (2||p1-p4||) is about 0.30 for an open eye and falls "
            "towards 0 when closed. Because eye shapes differ between people, the system learns each user's baseline during "
            "the first 45 frames and treats EAR below 74% of that baseline as closed. State rules: <b>DROWSY</b> if the eyes stay "
            "closed for 1.5 s; <b>WARNING</b> if the mouth stays open (MAR above 0.55) for 1 s or PERCLOS (share of the last "
            "30 s with closed eyes) reaches 25%; closures of 0.08-0.5 s are counted as normal blinks.")]

story += [P("<b>Mood logic (rule based).</b> All measurements are divided by the face width, so they do not change with "
            "distance. During the first 45 frames the program records the user's <i>neutral</i> face as a personal baseline. "
            "Each frame is then compared with that baseline using simple rules, and a majority vote over the last 12 frames "
            "removes flicker. Every threshold is stored in <font face='Courier'>config.py</font>."),
          table([["Mood", "Rule (compared with the user's neutral face)"],
                 ["HAPPY", "mouth corners rise above the lip centre and the mouth gets wider (or the Haar smile cascade agrees)"],
                 ["SURPRISED", "eyebrows raised at least 12% and the mouth opens clearly"],
                 ["ANGRY", "inner eyebrows pulled together (10% closer) and slightly lowered"],
                 ["SAD", "mouth corners drop below the lip centre without widening"],
                 ["TIRED", "eyes noticeably less open than neutral, or the drowsiness module reports WARNING / DROWSY"],
                 ["NEUTRAL", "none of the above"]], [2.4 * cm, 15.1 * cm]),
          Spacer(1, 4)]
story += figure("fig8_mood_icons.png", "Fig. 1 - The six moods the detector can report, drawn as cartoon icons on the live video.", width=12 * cm)
story += [P("<b>People-counting logic.</b> Mode 2 is still driven by motion: MOG2 finds the moving blobs and the centroid "
            "tracker gives each one an ID. A blob is a <b>PERSON</b> when a Haar face lies inside it (every face is one person, so a "
            "merged blob with two faces counts 2) or, when no face is visible, when it has a standing full-body shape (tall and "
            "narrow, at least 40% of the frame height). People who stop moving fade into the MOG2 background, so a Haar face search "
            "over the <i>whole</i> frame (every 2nd frame) also counts faces that are not inside any moving blob (labelled PERSON "
            "(still)); a faceless leftover blob next to a face is treated as the same person. The two sources are added, and a "
            "majority vote over the last 8 frames (at least 5 must agree) gives the stable number on screen. When it reaches "
            "<b>2 or more</b> the banner turns red, the program <b>beeps</b> every 1.5 s, one snapshot is saved and a "
            "MULTIPLE_PEOPLE line is written to the log; every change of the count is logged as well.")]
story += [P("<b>Interface.</b> The OpenCV window is resizable and can be maximized or minimized with the normal window buttons. "
            "A clickable toolbar switches modes, toggles the <b>mini view</b> (small always-on-top window with EXPAND / EXIT), "
            "fullscreen and help. Closing the window, pressing Q / Esc or clicking EXIT releases the camera, saves "
            "<font face='Courier'>output/session_summary.txt</font> and terminates the process immediately.")]

# ------------------------------------------------------------------ page 2
story += [P("4. Results and Screenshots", H2),
          P("Figures 2-9 are produced by <font face='Courier'>scripts/capture_screenshots.py</font> from the sample inputs in "
            "<font face='Courier'>samples/</font>. Each shows the processed frame (left), the live dashboard (right) and the "
            "toolbar (bottom) with bounding boxes, labels, landmarks, masks and graphs.")]
fig = [
    figure("fig1_drowsiness_calibrating.jpg",
           "Fig. 2 - Drowsiness + mood mode at start-up: Haar face and eye boxes, 68 landmarks, EAR/MAR, status banner, "
           "and the neutral-face calibration message. Panel: affine-aligned face, CLAHE image, EAR graph."),
    figure("fig2_mood_happy.jpg",
           "Fig. 3 - Mood detection: mouth corners above the neutral baseline give HAPPY; the badge, the panel row and the "
           "mood-mix bar update live. (Sample photo compared with a neutral baseline for demonstration.)"),
    figure("fig3_drowsiness_alert.jpg",
           "Fig. 4 - Eyes closed for more than 1.5 s: EAR 0.11 is below the personal threshold, the frame turns red and "
           "the DROWSY alarm fires (snapshot and CSV event saved)."),
    figure("fig7_mini_view.jpg",
           "Fig. 5 - Mini view: a small always-on-top window with EXPAND and EXIT buttons, handy while working in "
           "another program."),
    figure("fig4_people_one.jpg",
           "Fig. 6 - People counter, one person: PEOPLE = 1, green box with ID, trail, centroid and the Haar face; no alarm. "
           "Panel: MOG2 foreground mask, segmented person and the count over time."),
    figure("fig5_people_multiple.jpg",
           "Fig. 7 - A second person walks in: the count becomes 2, the banner and boxes turn red, the beep sounds and a "
           "snapshot and log entry are saved."),
    figure("fig9_people_still.jpg",
           "Fig. 8 - The left person stands still and has vanished from the foreground mask, yet the face search keeps "
           "counting them (PERSON (still)); the right person is the moving blob. PEOPLE = 2."),
    figure("fig6_object_tracker.jpg",
           "Fig. 9 - Tracker mode: hue-histogram back-projection (segmentation) and CamShift rotated box on the red ball."),
]
grid = Table([[fig[0], fig[1]], [fig[2], fig[3]], [fig[4], fig[5]], [fig[6], fig[7]]],
             colWidths=[8.8 * cm, 8.8 * cm])
grid.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                          ("LEFTPADDING", (0, 0), (-1, -1), 2), ("RIGHTPADDING", (0, 0), (-1, -1), 2)]))
story += [grid]

# ------------------------------------------------------------------ page 3
TRIALS = [["Test", "Input / frames", "Result", "Avg. time / frame"],
          ["Drowsiness + mood", "drowsy_demo.mp4, 249 frames",
           "2 blinks counted; DROWSY raised once after 1.5 s of closure; no false alarm on blinks; mood changed to "
           "TIRED during the closure", "44 ms"],
          ["Mood rules", "7 unit tests on real landmarks edited by hand",
           "neutral, happy, sad, surprised, angry, tired and the majority-vote filter all behave as specified", "-"],
          ["People counter (moving)", "walkers.mp4, 260 frames; 2 people on screen together for 30 frames",
           "Count went 0, 1, 2, 1, 0 as people came and went; the stable count equalled the true number on 91% of frames and "
           "every mismatch was the delay of the 8-frame vote (0.2 s after an entry, 0.4 s after an exit); the beep was "
           "requested only while 2 people were in view, with one snapshot and one log entry; IN = 1, OUT = 1 (correct)", "37 ms"],
          ["People counter (still person)", "people_demo.mp4, 300 frames; person A stands still for 10 s, B joins and leaves",
           "A stays in the count after MOG2 has absorbed them (found by the face search); count went 0, 1, 2, 1; 90% of frames "
           "exact, all others within 0.65 s of a real change; one alarm, no false alarm", "40 ms"],
          ["Object tracker", "color_ball.mp4, 240 frames", "0 frames lost by CamShift", "7 ms"]]
story += [P("5. Discussion: Accuracy, Behaviour and Limitations", H2),
          P("<b>Measured on the sample inputs</b> (CPU only, no GPU, display off, same machine for every row; 34 automated unit tests pass). These clips "
            "are synthetic or single-subject, so they verify that the logic works end to end; they are not a statistical "
            "accuracy study. Mood rules were verified by editing the landmarks of a real face and checking the decision; "
            "their accuracy on different live users depends on lighting and the quality of the landmark fit.")]
story += [table(TRIALS, [3.0 * cm, 4.0 * cm, 8.0 * cm, 2.5 * cm]), Spacer(1, 4)]
story += [P("<b>Behaviour.</b> Per-user EAR calibration, temporal rules (a blink is not drowsiness), a 5-frame grace period "
            "when Haar briefly loses the face, exponential smoothing of the face box and a 5-frame moving average of EAR/MAR "
            "reduce flicker and false alarms. In the people counter a low background learning rate keeps slow walkers "
            "visible, a closing kernel and a box-merging step combine the pieces of one body (head, arms, torso) into a single object, a blob must be tracked for 3 frames before it can count as a person, a person who disappears for up to 4 frames is still counted, the count is a majority vote over 8 frames so one missed or false face neither changes the number nor triggers the beep, a sudden change of more than 35% of the frame is treated as a lighting change, and a hysteresis band around the counting line prevents double counts. The full-frame face search runs on every 2nd frame (the slowest step), which keeps the program at about 25 frames per second on the test machine. Alarm events (DROWSY, YAWN, MULTIPLE_PEOPLE, every COUNT change, LINE_CROSS) are written to <font face='Courier'>output/events.csv</font>.")]
story += [P("<b>Limitations.</b>")]
story += bullets([
    "Haar cascades and LBF landmarks assume a mostly frontal, evenly lit face. Large head turns, glasses glare, heavy "
    "shadows or very low light lower accuracy (gamma correction and CLAHE reduce but do not remove this).",
    "EAR relies on landmark precision; very small faces (far from the camera) give noisy EAR values.",
    "The mood detector is rule based and reports <i>facial expression</i>, not true feelings. It needs a neutral face "
    "during calibration, subtle expressions can be missed, and people differ, so thresholds in config.py may need tuning "
    "(key D shows the live numbers).",
    "Background subtraction requires a static camera; sudden lighting changes or moving curtains create false motion until "
    "the model adapts. Overlapping people merge into one blob and the centroid tracker may swap IDs, which can distort the "
    "IN / OUT count.",
    "People counting needs a visible frontal face (at least 36 px wide) for people who stand still: somebody who stays "
    "motionless with their back turned is absorbed into the background and dropped from the count. People standing "
    "shoulder to shoulder are only counted as two when both faces are visible. The count is delayed by about 0.2-0.65 s "
    "because of the 8-frame vote. The test clips are synthetic (cartoon bodies with a real face photo); a test with real "
    "people, clothing and lighting is still needed.",
    "Colour tracking fails when the background has the same hue as the object.",
])
story += [P("6. Conclusion", H2),
          P("VisionGuard shows that classical computer vision can already solve two practical problems in real time on an "
            "ordinary laptop: it detects drowsiness and mood, counts the people in view and sounds an alarm when there is more than one, and integrates all six lab topics (image operations, segmentation, Haar cascades, analysis and "
            "transformation, motion and object tracking, facial landmarks) in one modular, well-commented Python code base "
            "with a live dashboard, logging and unit tests."),
          P("<b>Key learnings.</b> (1) Raw detections are not enough: the temporal logic (calibration, durations, smoothing, "
            "hysteresis) is what turns measurements into reliable behaviour. (2) Preprocessing such as CLAHE and gamma "
            "correction has a large effect on Haar and landmark stability. (3) Choosing parameters (Haar scale factor, MOG2 "
            "learning rate, morphology kernels) is a trade-off between speed, sensitivity and false positives."),
          P("<b>Possible improvements.</b> Head-pose estimation with solvePnP to detect nodding; a deep-learning face detector "
            "for large head angles; a HOG person detector (also classical) for people who face away; a Kalman filter or Hungarian matching for steadier tracking; e-mail / SMS alerts; and a GUI "
            "to tune thresholds live.")]

doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=1.7 * cm, rightMargin=1.7 * cm,
                        topMargin=1.5 * cm, bottomMargin=1.4 * cm,
                        title="VisionGuard - CSC 126 Midterm Documentation")
doc.build(story)
print("written", OUT)
