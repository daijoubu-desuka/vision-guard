"""
capture_screenshots.py - Runs the app on the sample inputs and saves the
annotated frames used as figures in the documentation (docs/screenshots/).

For your FINAL report, replace these with screenshots taken from your own
LIVE WEBCAM run (press P in the app) and keep the same file names.

    python scripts/capture_screenshots.py
"""
import argparse
import os
import sys

import cv2
import numpy as np

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)
os.chdir(ROOT)
import hud  # noqa: E402
import main as vg  # noqa: E402
import mood as md  # noqa: E402

OUT = "docs/screenshots"


def make_app(video, mode, roi=None):
    ns = argparse.Namespace(video=video, image=None, camera=0, mode=mode, roi=roi,
                            output=None, no_display=True, no_alarm=True, max_frames=0)
    return vg.VisionGuardApp(ns)


def run(video, mode, wanted, roi=None):
    """wanted = {frame_index: output_file_name}   (a name starting 'mini:' = mini view)"""
    app = make_app(video, mode, roi)
    cap = cv2.VideoCapture(video)
    fps = cap.get(cv2.CAP_PROP_FPS) or 20.0
    i = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        img, _ = app.process(frame, i / fps)
        if i in wanted:
            name = wanted[i]
            if name.startswith("mini:"):
                app.view = "mini"
                img = app.render(app.last_comp)
                app.view = "full"
                name = name[5:]
            cv2.imwrite(os.path.join(OUT, name), img)
            print("saved", name)
        i += 1
    app.logger.close()


def mood_demo():
    """
    Staged mood figure: the sample photo shows a smiling person, so we give the
    detector a NEUTRAL baseline built from the same landmarks (corners lowered).
    With a real webcam the baseline is learned from your own neutral face.
    """
    app = make_app("samples/drowsy_demo.mp4", "drowsiness")
    img = cv2.imread("samples/face_sample.jpg")
    det = app._drowsy()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face = det.detect_face(gray)
    pts = det.detect_landmarks(gray, face)
    w = float(np.linalg.norm(pts[0] - pts[16]))
    neutral = pts.copy()
    neutral[48] += (0.03 * w, 0.035 * w)
    neutral[54] += (-0.03 * w, 0.035 * w)
    from drowsiness import INNER_MOUTH, mouth_aspect_ratio
    app.mood.set_baseline(md.mood_features(neutral, mouth_aspect_ratio(neutral[INNER_MOUTH]), 0.30))
    out = None
    for i in range(30):
        out, _ = app.process(img, i / 20)
    cv2.imwrite(os.path.join(OUT, "fig2_mood_happy.jpg"), out)
    print("saved fig2_mood_happy.jpg")
    app.logger.close()


def mood_icons():
    """Strip with the six moods the detector can output."""
    moods = md.MOODS
    cell = 120
    strip = np.full((cell + 30, cell * len(moods), 3), 245, np.uint8)
    for i, m in enumerate(moods):
        hud.draw_mood_icon(strip, (i * cell + cell // 2, 52), 40, m)
        (tw, _), _ = cv2.getTextSize(m, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 2)
        cv2.putText(strip, m, (i * cell + (cell - tw) // 2, cell + 12), cv2.FONT_HERSHEY_SIMPLEX,
                    0.55, (40, 40, 40), 2, cv2.LINE_AA)
    cv2.imwrite(os.path.join(OUT, "fig8_mood_icons.png"), strip)
    print("saved fig8_mood_icons.png")


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    for f in os.listdir(OUT):
        os.remove(os.path.join(OUT, f))
    run("samples/drowsy_demo.mp4", "drowsiness",
        {30: "fig1_drowsiness_calibrating.jpg", 150: "fig3_drowsiness_alert.jpg",
         151: "mini:fig7_mini_view.jpg"})
    mood_demo()
    run("samples/walkers.mp4", "people",
        {100: "fig4_people_one.jpg", 135: "fig5_people_multiple.jpg"})
    run("samples/people_demo.mp4", "people", {200: "fig9_people_still.jpg"})
    run("samples/color_ball.mp4", "tracker", {110: "fig6_object_tracker.jpg"}, roi="286,306,68,68")
    mood_icons()
