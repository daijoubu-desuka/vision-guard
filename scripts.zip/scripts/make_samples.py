"""
make_samples.py - Generates the small SYNTHETIC test videos in samples/ so the
project can be run and demonstrated without a webcam (e.g. in the repo CI or
when grading). Real webcam use is the intended way to run the app.

    python scripts/make_samples.py

Creates
    samples/walkers.mp4     two "people" crossing a counting line, overlapping in time (people counter)
    samples/people_demo.mp4 one person walks in and STANDS STILL, a second joins, then leaves (people counter)
    samples/color_ball.mp4  a red ball moving on a textured background (tracker mode)
    samples/drowsy_demo.mp4 a face that blinks and then keeps its eyes closed (drowsiness mode)
"""
import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import utils  # noqa: E402
from drowsiness import DrowsinessDetector, RIGHT_EYE, LEFT_EYE  # noqa: E402

W, H, FPS = 640, 480, 20


def writer(path, size=(W, H)):
    return cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*"mp4v"), FPS, size)


def background():
    """Static textured 'room' so background subtraction has something to learn."""
    rng = np.random.default_rng(1)
    bg = np.full((H, W, 3), (150, 150, 140), np.uint8)
    noise = rng.integers(-12, 12, (H, W, 1)).astype(np.int16)
    bg = np.clip(bg.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    cv2.rectangle(bg, (0, 380), (W, H), (110, 120, 120), -1)          # floor
    cv2.rectangle(bg, (40, 60), (200, 220), (180, 160, 120), -1)      # picture frame
    cv2.rectangle(bg, (450, 80), (600, 300), (120, 110, 100), -1)     # door
    return cv2.GaussianBlur(bg, (3, 3), 0)


def make_walkers(path, face_img):
    bg = background()
    face = cv2.resize(face_img, (70, 70))
    out = writer(path)
    total = 260
    for f in range(total):
        frame = bg.copy()
        # person A walks DOWN the frame (IN) between frames 60 and 150
        # person B walks UP the frame (OUT) between frames 120 and 220
        for start, end, x, going_down, shirt in ((60, 150, 220, True, (60, 60, 200)),
                                                  (120, 220, 420, False, (200, 120, 40))):
            if start <= f < end:
                t = (f - start) / (end - start)
                y_top = int(20 + 260 * t) if going_down else int(320 - 200 * t)
                cv2.rectangle(frame, (x - 40, y_top + 70), (x + 40, y_top + 190), shirt, -1)   # body
                for stripe in range(y_top + 78, y_top + 190, 16):                             # texture
                    cv2.line(frame, (x - 40, stripe), (x + 40, stripe), (255, 255, 255), 3)
                cv2.rectangle(frame, (x - 35, y_top + 190), (x + 35, y_top + 260), (80, 50, 40), -1)  # legs
                frame[y_top: y_top + 70, x - 35: x + 35] = face                               # head
        out.write(frame)
    out.release()


def draw_person(frame, x, y_top, shirt, face):
    """Same cartoon person as in make_walkers: striped body, legs and a real face photo as the head."""
    cv2.rectangle(frame, (x - 40, y_top + 70), (x + 40, y_top + 190), shirt, -1)
    for stripe in range(y_top + 78, y_top + 190, 16):
        cv2.line(frame, (x - 40, stripe), (x + 40, stripe), (255, 255, 255), 3)
    cv2.rectangle(frame, (x - 35, y_top + 190), (x + 35, y_top + 260), (80, 50, 40), -1)
    x0, y0 = x - 35, y_top
    h, w = face.shape[:2]
    sx0, sy0 = max(-x0, 0), max(-y0, 0)                        # clip when the head is partly outside the frame
    ex, ey = min(w, frame.shape[1] - x0), min(h, frame.shape[0] - y0)
    if ex > sx0 and ey > sy0:
        frame[y0 + sy0: y0 + ey, x0 + sx0: x0 + ex] = face[sy0:ey, sx0:ex]


# Ground truth of people_demo.mp4 (frame numbers at 20 fps): person A walks in from the left (frames 50-100)
# and then stands still until the end; person B walks in from the right (130-180), stands, and leaves (230-280).
PEOPLE_DEMO_FRAMES = 300


def people_demo_truth(f):
    """How many people are really in view at frame f (head centre inside the image)."""
    a_x = -50 + 240 * min(max((f - 50) / 50, 0), 1)
    b_x = 700 - 250 * min(max((f - 130) / 50, 0), 1) if f < 230 else 450 + 250 * min((f - 230) / 50, 1)
    return int(0 <= a_x <= 640) + int(f >= 130 and 0 <= b_x <= 640)


def make_people_demo(path, face_img):
    bg = background()
    face = cv2.resize(face_img, (70, 70))
    out = writer(path)
    rng = np.random.default_rng(5)
    for f in range(PEOPLE_DEMO_FRAMES):
        frame = bg.copy()
        a_x = int(-50 + 240 * min(max((f - 50) / 50, 0), 1))
        draw_person(frame, a_x, 120, (60, 60, 200), face)                         # person A (stops at frame 100)
        if 130 <= f:
            b_x = int(700 - 250 * min((f - 130) / 50, 1)) if f < 230 else int(450 + 250 * min((f - 230) / 50, 1))
            draw_person(frame, b_x, 120, (200, 120, 40), face)                    # person B (comes and goes)
        noise = rng.integers(-2, 3, frame.shape).astype(np.int16)                 # tiny sensor noise
        out.write(np.clip(frame.astype(np.int16) + noise, 0, 255).astype(np.uint8))
    out.release()


def make_ball(path):
    bg = background()
    out = writer(path)
    for f in range(240):
        frame = bg.copy()
        x = int(320 + 220 * np.sin(f / 30.0))
        y = int(240 + 120 * np.sin(f / 19.0 + 1))
        cv2.circle(frame, (x, y), 34, (30, 30, 220), -1)             # red ball (BGR)
        cv2.circle(frame, (x - 10, y - 10), 8, (120, 120, 255), -1)  # highlight
        out.write(frame)
    out.release()
    return (320 - 34, 240 + int(120 * np.sin(1)) - 34, 68, 68)         # initial ROI of frame 0


def paint_closed_eyes(frame, pts):
    """Cover each eye with skin tone + a dark lash line = closed eye."""
    for idx in (RIGHT_EYE, LEFT_EYE):
        eye = pts[idx].astype(np.int32)
        x, y, w, h = cv2.boundingRect(eye)
        patch = frame[max(y - 8, 0): y - 4, x: x + w]
        skin = tuple(int(v) for v in patch.reshape(-1, 3).mean(axis=0)) if patch.size else (160, 170, 210)
        cv2.ellipse(frame, (x + w // 2, y + h // 2), (w // 2 + 4, h // 2 + 5), 0, 0, 360, skin, -1)
        cv2.line(frame, (x, y + h // 2), (x + w, y + h // 2), (40, 40, 60), 2)


def make_drowsy(path, face_img):
    """Timeline: open 3 s, blink, open 2 s, eyes closed 3 s, open 2 s, blink, open 2 s."""
    det = DrowsinessDetector(utils.ensure_landmark_model())
    gray = cv2.cvtColor(face_img, cv2.COLOR_BGR2GRAY)
    face = det.detect_face(gray)
    pts = det.detect_landmarks(gray, face)
    timeline = [("open", 3.0), ("closed", 0.25), ("open", 2.0), ("closed", 3.0),
                ("open", 2.0), ("closed", 0.2), ("open", 2.0)]
    out = writer(path, (face_img.shape[1], face_img.shape[0]))
    rng = np.random.default_rng(3)
    for kind, dur in timeline:
        for _ in range(int(dur * FPS)):
            frame = face_img.copy()
            if kind == "closed":
                paint_closed_eyes(frame, pts)
            noise = rng.integers(-3, 3, frame.shape).astype(np.int16)      # tiny sensor noise
            out.write(np.clip(frame.astype(np.int16) + noise, 0, 255).astype(np.uint8))
    out.release()


if __name__ == "__main__":
    face_img = cv2.imread("samples/face_sample.jpg")
    head = face_img[40:200, 150:330]                                 # crop of the face for the walkers
    make_walkers("samples/walkers.mp4", head)
    make_people_demo("samples/people_demo.mp4", head)
    roi = make_ball("samples/color_ball.mp4")
    make_drowsy("samples/drowsy_demo.mp4", face_img)
    print("samples written. Ball ROI for tracker mode:", ",".join(map(str, roi)))
