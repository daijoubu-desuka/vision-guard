"""
Unit tests for the logic that does not need a webcam.
Run with:  python -m unittest discover -s tests -v
"""
import os
import sys
import unittest
from unittest import mock

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import config  # noqa: E402
import drowsiness as dz  # noqa: E402
import preprocessing as pre  # noqa: E402
from motion import (CentroidTracker, LineCounter, MotionDetector, PeopleCounter,  # noqa: E402
                    TrackedObject, merge_detections)

MODEL = config.LANDMARK_MODEL_FILE
HAVE_MODEL = os.path.exists(MODEL) and os.path.getsize(MODEL) > 1_000_000


class TestMetrics(unittest.TestCase):
    def test_ear_open_vs_closed(self):
        open_eye = np.array([[0, 5], [3, 1], [7, 1], [10, 5], [7, 9], [3, 9]], float)
        closed_eye = np.array([[0, 5], [3, 4.4], [7, 4.4], [10, 5], [7, 5.6], [3, 5.6]], float)
        self.assertGreater(dz.eye_aspect_ratio(open_eye), 0.6)
        self.assertLess(dz.eye_aspect_ratio(closed_eye), 0.2)

    def test_mar_yawn(self):
        shut = np.array([[0, 5], [2, 5], [4, 5], [6, 5], [8, 5], [6, 5], [4, 5], [2, 5]], float)
        wide = np.array([[0, 5], [2, 1], [4, 0], [6, 1], [8, 5], [6, 9], [4, 10], [2, 9]], float)
        self.assertLess(dz.mouth_aspect_ratio(shut), 0.05)
        self.assertGreater(dz.mouth_aspect_ratio(wide), config.MAR_YAWN_THRESHOLD)


class TestPreprocessing(unittest.TestCase):
    def test_gamma_brightens_dark_frame(self):
        dark = np.full((50, 50, 3), 30, np.uint8)
        bright, gamma = pre.auto_gamma(dark, 30.0)
        self.assertLess(gamma, 1.0)
        self.assertGreater(bright.mean(), dark.mean())

    def test_gamma_leaves_normal_frame(self):
        normal = np.full((50, 50, 3), 128, np.uint8)
        same, gamma = pre.auto_gamma(normal, 128.0)
        self.assertEqual(gamma, 1.0)
        self.assertTrue(np.array_equal(same, normal))


class TestMerging(unittest.TestCase):
    def test_pieces_of_one_person_become_one_object(self):
        # head, torso and an arm of the same person, detected as separate blobs
        pieces = [(200, 100, 60, 60, 2500, 230, 130), (190, 170, 90, 150, 9000, 235, 245),
                  (280, 180, 40, 90, 2000, 300, 225)]
        merged = merge_detections(pieces)
        self.assertEqual(len(merged), 1)
        self.assertEqual(merged[0][4], 13500)               # areas add up

    def test_far_apart_objects_stay_separate(self):
        pieces = [(10, 10, 50, 100, 4000, 35, 60), (500, 300, 50, 100, 4000, 525, 350)]
        self.assertEqual(len(merge_detections(pieces)), 2)

    def test_one_frame_noise_is_not_confirmed(self):
        tr = CentroidTracker()
        objs = tr.update([((100, 100, 80, 80), (140, 140))])
        self.assertFalse(list(objs.values())[0].confirmed)
        for _ in range(config.TRACK_CONFIRM_FRAMES):
            objs = tr.update([((100, 100, 80, 80), (140, 140))])
        self.assertTrue(list(objs.values())[0].confirmed)


class TestTracking(unittest.TestCase):
    def test_id_is_kept_while_moving(self):
        tr = CentroidTracker()
        for x in range(100, 160, 5):
            objs = tr.update([((x, 100, 50, 80), (x + 25, 140))])
        self.assertEqual(list(objs.keys()), [0])

    def test_line_counter_counts_one_entry_and_one_exit(self):
        tr, lc = CentroidTracker(), LineCounter(480)
        for y in range(100, 400, 10):                       # walks down -> IN
            lc.update(tr.update([((100, y, 50, 80), (125, y))]))
        for y in range(400, 100, -10):                      # walks up -> OUT
            lc.update(tr.update([((100, y, 50, 80), (125, y))]))
        self.assertEqual((lc.count_in, lc.count_out), (1, 1))


@unittest.skipUnless(HAVE_MODEL, "landmark model not downloaded (run download_models.py)")
class TestDrowsinessLogic(unittest.TestCase):
    def setUp(self):
        self.det = dz.DrowsinessDetector(MODEL)
        self.det.calibrated, self.det.baseline_ear = True, 0.32   # skip calibration

    def feed(self, ear, mar, t):
        res = dz.DrowsinessResult(ear=ear, mar=mar, face=(0, 0, 100, 100), eyes=[(0, 0, 1, 1)] * 2,
                                  ear_threshold=0.32 * config.EAR_CLOSED_RATIO)
        self.det._update_state(res, t)
        return res

    def test_blink_is_counted_but_not_drowsy(self):
        for i in range(10):
            self.feed(0.32, 0.2, i * 0.05)
        for i in range(10, 16):                              # 0.3 s closure
            r = self.feed(0.10, 0.2, i * 0.05)
        r = self.feed(0.32, 0.2, 0.9)
        self.assertEqual(r.blinks, 1)
        self.assertNotEqual(r.state, "DROWSY")

    def test_long_closure_triggers_drowsy(self):
        state, events = None, []
        for i in range(60):                                  # 3 s of closed eyes at 20 fps
            r = self.feed(0.08, 0.2, i * 0.05)
            state = r.state
            events += r.events
        self.assertEqual(state, "DROWSY")
        self.assertEqual(events.count("DROWSY"), 1)          # logged once, not every frame

    def test_yawn_detected_after_one_second(self):
        events = []
        for i in range(40):                                  # 2 s mouth wide open
            r = self.feed(0.32, 0.8, i * 0.05)
            events += r.events
        self.assertEqual(events.count("YAWN"), 1)
        self.assertEqual(r.yawns, 1)

    def test_pipeline_on_face_image(self):
        img = cv2.imread(os.path.join(os.path.dirname(__file__), "..", "samples", "face_sample.jpg"))
        if img is None:
            self.skipTest("sample image missing")
        gray = pre.enhance_contrast(pre.to_gray(img))
        det = dz.DrowsinessDetector(MODEL)
        res = det.analyse(img, gray, 0.0)
        self.assertIsNotNone(res.face)
        self.assertEqual(res.landmarks.shape, (68, 2))
        self.assertGreater(res.ear, 0.2)


@unittest.skipUnless(HAVE_MODEL, "landmark model not downloaded (run download_models.py)")
class TestMood(unittest.TestCase):
    """Rule table tested with a real face's landmarks that we deform by hand."""

    @classmethod
    def setUpClass(cls):
        import mood as md
        cls.md = md
        img = cv2.imread(os.path.join(os.path.dirname(__file__), "..", "samples", "face_sample.jpg"))
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        det = dz.DrowsinessDetector(MODEL)
        face = det.detect_face(gray)
        cls.pts = det.detect_landmarks(gray, face)
        cls.w = float(np.linalg.norm(cls.pts[0] - cls.pts[16]))
        cls.base = md.mood_features(cls.pts, dz.mouth_aspect_ratio(cls.pts[dz.INNER_MOUTH]), 0.30)

    def feats(self, edit):
        p = self.pts.copy()
        edit(p, self.w)
        mar = dz.mouth_aspect_ratio(p[dz.INNER_MOUTH])
        return self.md.mood_features(p, mar, 0.30)

    def mood(self, edit, **kw):
        return self.md.classify_mood(self.feats(edit), self.base, **kw)

    def test_neutral_when_unchanged(self):
        self.assertEqual(self.mood(lambda p, w: None), "NEUTRAL")

    def test_happy_corners_up_and_wider(self):
        def e(p, w):
            p[48] += (-0.03 * w, -0.04 * w); p[54] += (0.03 * w, -0.04 * w)
        self.assertEqual(self.mood(e), "HAPPY")

    def test_sad_corners_down(self):
        def e(p, w):
            p[48] += (0, 0.03 * w); p[54] += (0, 0.03 * w)
        self.assertEqual(self.mood(e), "SAD")

    def test_surprised_brows_up_mouth_open(self):
        def e(p, w):
            p[17:27] += (0, -0.06 * w)
            p[[57, 65, 66, 67]] += (0, 0.12 * w)
        self.assertEqual(self.mood(e), "SURPRISED")

    def test_angry_inner_brows_down_and_together(self):
        def e(p, w):
            p[21] += (0.04 * w, 0.03 * w); p[22] += (-0.04 * w, 0.03 * w)
            p[17:27] += (0, 0.01 * w)
        self.assertEqual(self.mood(e), "ANGRY")

    def test_tired_when_fatigue_flag(self):
        self.assertEqual(self.mood(lambda p, w: None, fatigue=True), "TIRED")

    def test_majority_vote_prevents_flicker(self):
        det = self.md.MoodDetector()
        det.set_baseline(self.base)
        res = dz.DrowsinessResult(landmarks=self.pts, ear=0.30, mar=self.base["mar"],
                                  face=(0, 0, 100, 100), state="AWAKE")
        gray = np.zeros((200, 200), np.uint8)
        for _ in range(12):
            det.update(res, gray)
        before = det.mood
        det.history.append("SAD")                      # one odd frame must not change the mood
        label, votes = self.md.Counter(det.history).most_common(1)[0]
        self.assertEqual(before, "NEUTRAL")
        self.assertEqual(label, "NEUTRAL")


class TestPeopleCounter(unittest.TestCase):
    """Mode 2: counting people from tracked blobs + Haar faces (faces are stubbed, no camera needed)."""
    H = 480
    BODY = (200, 100, 90, 270)            # tall, narrow blob = a standing person

    def setUp(self):
        patcher = mock.patch.object(config, "PEOPLE_FACE_EVERY", 1)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.pc = PeopleCounter()
        self.faces = []
        self.pc.detect_faces = lambda gray: list(self.faces)

    @staticmethod
    def obj(oid, bbox, hits=10, gone=0):
        x, y, w, h = bbox
        return TrackedObject(oid, (x + w // 2, y + h // 2), bbox, hits=hits, disappeared=gone)

    def run_frames(self, objects, n=config.PEOPLE_SMOOTH_FRAMES):
        for _ in range(n):
            res = self.pc.update({o.object_id: o for o in objects}, None, self.H)
        return res

    def test_nobody(self):
        self.assertEqual(self.run_frames([]).count, 0)

    def test_one_moving_person_with_face(self):
        self.faces = [(225, 120, 45, 45)]
        res = self.run_frames([self.obj(0, self.BODY)])
        self.assertEqual(res.count, 1)
        self.assertFalse(res.multiple)                    # one person: no alarm

    def test_full_body_shape_counts_without_a_face(self):
        res = self.run_frames([self.obj(0, self.BODY)])   # e.g. person with the back turned
        self.assertEqual(res.count, 1)

    def test_small_moving_object_is_not_a_person(self):
        res = self.run_frames([self.obj(0, (300, 300, 60, 50))])    # a pet / bag / curtain
        self.assertEqual(res.count, 0)

    def test_two_separate_people_trigger_the_alert(self):
        self.faces = [(225, 120, 45, 45), (445, 120, 45, 45)]
        res = self.run_frames([self.obj(0, self.BODY), self.obj(1, (420, 100, 90, 270))])
        self.assertEqual(res.count, 2)
        self.assertTrue(res.multiple)                     # more than one person -> beep

    def test_two_faces_in_one_merged_blob_count_as_two(self):
        self.faces = [(215, 120, 45, 45), (265, 125, 45, 45)]
        res = self.run_frames([self.obj(0, (200, 100, 150, 270))])
        self.assertEqual(res.count, 2)

    def test_person_who_stands_still_is_still_counted(self):
        self.faces = [(225, 120, 45, 45)]                 # no moving blob any more (absorbed by MOG2)
        res = self.run_frames([])
        self.assertEqual((res.count, len(res.standalone_faces)), (1, 1))

    def test_leftover_blob_and_face_are_one_person(self):
        self.faces = [(165, 130, 44, 44)]                 # face just left of a thin leftover blob
        res = self.run_frames([self.obj(0, (198, 116, 39, 268))])
        self.assertEqual(res.raw_count, 1)                # not 2

    def test_one_missed_frame_does_not_change_the_count(self):
        self.faces = [(225, 120, 45, 45)]
        self.run_frames([self.obj(0, self.BODY)])
        self.faces = []                                   # Haar misses the face for one frame
        res = self.pc.update({0: self.obj(0, self.BODY)}, None, self.H)
        self.assertEqual(res.count, 1)

    def test_single_false_face_does_not_trigger_the_alert(self):
        self.faces = [(225, 120, 45, 45)]
        self.run_frames([self.obj(0, self.BODY)])
        self.faces = [(225, 120, 45, 45), (20, 20, 40, 40)]     # one spurious detection
        res = self.pc.update({0: self.obj(0, self.BODY)}, None, self.H)
        self.assertEqual(res.raw_count, 2)
        self.assertFalse(res.multiple)                    # the vote needs several frames in a row

    def test_unconfirmed_blob_is_ignored(self):
        res = self.run_frames([self.obj(0, self.BODY, hits=1)])
        self.assertEqual(res.count, 0)

    def test_peak_and_reset(self):
        self.faces = [(225, 120, 45, 45), (445, 120, 45, 45)]
        self.run_frames([])
        self.assertEqual(self.pc.peak, 2)
        self.pc.reset()
        self.assertEqual((self.pc.count, self.pc.peak), (0, 0))


class TestBeepOnMoreThanOnePerson(unittest.TestCase):
    """The alarm must sound while 2+ people are in view and stay silent otherwise."""
    VIDEO = os.path.join(os.path.dirname(__file__), "..", "samples", "walkers.mp4")

    @unittest.skipUnless(os.path.exists(VIDEO), "samples/walkers.mp4 missing (run scripts/make_samples.py)")
    def test_beep_only_while_two_or_more(self):
        import argparse
        import main as vg

        class Recorder:
            def __init__(self):
                self.calls = 0

            def beep(self, *args, **kwargs):
                self.calls += 1

        ns = argparse.Namespace(video=self.VIDEO, image=None, camera=0, mode="people", roi=None,
                                output=None, no_display=True, no_alarm=True, max_frames=0)
        app = vg.VisionGuardApp(ns)
        app.alarm = Recorder()
        cap = cv2.VideoCapture(self.VIDEO)
        beeps_with_one_or_none, beeps_with_many, frames_with_many, i = 0, 0, 0, 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            before = app.alarm.calls
            app.process(frame, i / 20.0)
            fired = app.alarm.calls - before
            if app.prev_count >= config.PEOPLE_ALERT_COUNT:
                frames_with_many += 1
                beeps_with_many += fired
            else:
                beeps_with_one_or_none += fired
            i += 1
        app.logger.close()
        self.assertGreater(frames_with_many, 0)
        self.assertEqual(beeps_with_many, frames_with_many)       # a beep request on every alert frame
        self.assertEqual(beeps_with_one_or_none, 0)               # never for 0 or 1 person
        self.assertEqual(app.alerts, 1)                           # one alert event for the whole clip


class TestPeopleCounterOnVideo(unittest.TestCase):
    """End to end on the synthetic clip: one person walks in and stands still, a second joins, then leaves."""
    VIDEO = os.path.join(os.path.dirname(__file__), "..", "samples", "people_demo.mp4")

    @unittest.skipUnless(os.path.exists(VIDEO), "samples/people_demo.mp4 missing (run scripts/make_samples.py)")
    def test_counts_follow_the_clip(self):
        motion, tracker, pc = MotionDetector(detect_faces=False), CentroidTracker(), PeopleCounter()
        cap = cv2.VideoCapture(self.VIDEO)
        counts = []
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame = pre.resize_to_width(frame)
            gray = pre.to_gray(frame)
            res = motion.process(pre.blur(frame, 5), pre.blur(gray, 5))
            objs = tracker.update(res.detections)
            counts.append(pc.update(objs, pre.enhance_contrast(gray), frame.shape[0]).count)
        self.assertEqual(counts[40], 0)                   # empty room
        self.assertEqual(counts[120], 1)                  # A standing in view
        self.assertEqual(counts[200], 2)                  # A (still) + B -> alarm level
        self.assertEqual(counts[-1], 1)                   # B left, A is STILL counted although not moving
        self.assertEqual(pc.peak, 2)


if __name__ == "__main__":
    unittest.main()
